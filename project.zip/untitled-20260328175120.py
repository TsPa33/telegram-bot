import urllib.request
import urllib.parse
import json
import time

TOKEN = "AAE9C5FkqcCNlqqz9EExIIc7TIeYy9KtPBw"
URL = f"https://api.telegram.org/bot/AAE9C5FkqcCNlqqz9EExIIc7TIeYy9KtPBw"

offset = 0

while True:
    # Отримуємо нові повідомлення
    with urllib.request.urlopen(f"{URL}getUpdates?offset={offset}") as response:
        data = json.loads(response.read())

    for item in data["result"]:
        chat_id = item["message"]["chat"]["id"]
        text_received = item["message"]["text"]
        
        # Відповідь бота
        text_to_send = f"Ти написав: {text_received}"
        params = urllib.parse.urlencode({"chat_id": chat_id, "text": text_to_send}).encode()
        urllib.request.urlopen(f"{URL}sendMessage", params)
        
        # Оновлюємо offset, щоб не обробляти повідомлення повторно
        offset = item["update_id"] + 1

    time.sleep(1)